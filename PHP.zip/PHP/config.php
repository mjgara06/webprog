<?php

$host = 'localhost';
$user = 'mjeg';
$password = 'melvz';

$conn = pg_connect("host=localhost user=mjeg password=melvz dbname=mjeg");
if ( $conn === FALSE ){
	die();
	}



?>
