<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:483px;
	height:80px;
	z-index:1;
	left: 161px;
	top: 21px;
}
.style1 {font-size: 50px}
.style2 {font-size: 16px}
-->
</style>
<html>
<body>
  <p align="center">access denied </p>
  <p align="center" class="style2"><a href="login.php">login</a></p>
</div>
</body>
</html>
